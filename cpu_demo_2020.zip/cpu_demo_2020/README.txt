To run:
$ make
$ ./bins/cpu_run test_cases/test1.txt
OR
$ ./bins/cpu_run test_cases/test2.txt
OR
$ ./bins/cpu_run test_cases/test3.txt
OR
$ ./bins/cpu_run test_cases/test4.txt
OR
$ ./bins/cpu_run test_cases/test5.txt